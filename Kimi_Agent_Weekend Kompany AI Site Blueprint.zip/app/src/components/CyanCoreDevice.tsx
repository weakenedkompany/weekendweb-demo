import { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Environment } from '@react-three/drei'
import * as THREE from 'three'
import { easing } from 'maath'

function InnerScreen() {
  const materialRef = useRef<THREE.MeshPhysicalMaterial>(null)

  useFrame((state) => {
    if (materialRef.current) {
      const mat = materialRef.current as THREE.MeshPhysicalMaterial & { uniforms?: Record<string, { value: number }> }
      if (mat.uniforms) {
        mat.uniforms.time.value = state.clock.elapsedTime
      }
    }
  })

  const onBeforeCompile = (shader: THREE.WebGLProgramParametersWithUniforms) => {
    shader.uniforms.time = { value: 0 }
    ;(materialRef.current as unknown as { uniforms?: Record<string, { value: number }> }).uniforms = shader.uniforms

    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <common>',
      `#include <common>
      uniform float time;
      vec3 palette(float t) {
        vec3 a = vec3(0.5, 0.5, 0.5);
        vec3 b = vec3(0.5, 0.5, 0.5);
        vec3 c = vec3(1.0, 1.0, 1.0);
        vec3 d = vec3(0.00, 0.33, 0.67);
        return a + b * cos(6.28318 * (c * t + d));
      }`
    )

    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <map_fragment>',
      `#include <map_fragment>
      float distanceToCenter = distance(vUv, vec2(0.5));
      float oscillation = sin(distanceToCenter * 8.0 - time * 1.5) * 0.5 + 0.5;
      vec3 color = palette(oscillation);
      diffuseColor.rgb += color * 0.5;`
    )
  }

  return (
    <mesh position={[0, 0, -0.01]}>
      <planeGeometry args={[3.2, 1.6]} />
      <meshPhysicalMaterial
        ref={materialRef}
        transmission={0.2}
        roughness={0.2}
        metalness={0.1}
        clearcoat={0}
        color="#050505"
        transparent
        onBeforeCompile={onBeforeCompile}
      />
    </mesh>
  )
}

function DeviceGroup() {
  const groupRef = useRef<THREE.Group>(null)
  const rigRef = useRef<THREE.Group>(null)

  useFrame((state, delta) => {
    if (!rigRef.current || !groupRef.current) return

    // Gentle parent orbit
    groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.2) * 0.05
    groupRef.current.rotation.x = Math.cos(state.clock.elapsedTime * 0.3) * 0.05

    // Mouse follow with easing
    const mouseX = (state.pointer.x * Math.PI) / 10
    const mouseY = (state.pointer.y * Math.PI) / 10
    easing.dampE(
      rigRef.current.rotation,
      new THREE.Euler(mouseY, mouseX, 0),
      0.4,
      delta
    )
  })

  return (
    <group ref={groupRef}>
      <group ref={rigRef}>
        {/* Main Glass Slab */}
        <mesh>
          <boxGeometry args={[3.5, 1.85, 0.05]} />
          <meshPhysicalMaterial
            transmission={1}
            thickness={1.5}
            roughness={0}
            metalness={0.1}
            ior={1.9}
            color="#050505"
            transparent
            opacity={1}
            clearcoat={1}
          />
        </mesh>

        {/* Edge Glow */}
        <mesh scale={[1.05, 1.05, 1.05]}>
          <boxGeometry args={[3.5, 1.85, 0.05]} />
          <meshStandardMaterial
            color="#06b6d4"
            transparent
            opacity={0.15}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
            side={THREE.BackSide}
          />
        </mesh>

        {/* Inner Screen */}
        <InnerScreen />

        {/* Back inset box */}
        <mesh position={[0, 0, -0.06]}>
          <boxGeometry args={[0.22, 0.22, 0.04]} />
          <meshPhysicalMaterial
            color="#0a0a0f"
            metalness={0.5}
            roughness={0.3}
          />
        </mesh>
      </group>
    </group>
  )
}

export default function CyanCoreDevice() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        dpr={[1, 2]}
        camera={{ position: [0, 0, 6], fov: 45 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: 'transparent' }}
      >
        <ambientLight intensity={0.5} color="#e0f7fa" />
        <spotLight
          position={[5, 5, 5]}
          intensity={10}
          angle={0.4}
          color="#ffffff"
          penumbra={0.5}
        />
        {/* Three cyan point lights behind */}
        <pointLight position={[-2, 1, -3]} distance={10} intensity={40} color="#06b6d4" />
        <pointLight position={[2, -1, -3]} distance={10} intensity={40} color="#06b6d4" />
        <pointLight position={[0, 0, -4]} distance={10} intensity={30} color="#06b6d4" />

        <DeviceGroup />
        <Environment preset="studio" blur={10.5} />
      </Canvas>
    </div>
  )
}
